# Germans PC
Оболочка для запуска .exe на Android (arm64) через Box64 + Wine.
Открыть папку в Android Studio -> Sync -> Run.

Что сделано: интерфейс (сетка программ, выбор .exe, фокус для геймпада/клавиатуры),
перехват ввода (клавиатура, мышь, геймпад), каркас запуска.
Что осталось: положить Box64 + Wine в assets/engine.tar.xz (Engine.install),
добавить XServer/рендер и передачу ввода в Wine (RunnerActivity: TODO).
