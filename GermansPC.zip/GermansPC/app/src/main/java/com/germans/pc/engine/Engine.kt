package com.germans.pc.engine

import android.content.Context
import java.io.File

data class AppEntry(val name: String, val exePath: String, val wineArgs: String = "")

/** Слой запуска. Сюда подключаются Box64 + Wine, упакованные в assets/engine.tar.xz. */
class Engine(private val ctx: Context) {
    private val root = File(ctx.filesDir, "engine")

    fun isInstalled() = File(root, "bin/box64").exists() && File(root, "wine/bin/wine64").exists()

    /** TODO: распаковать assets/engine.tar.xz в filesDir/engine (один раз). */
    fun install() { root.mkdirs() }

    fun launch(entry: AppEntry): Process {
        val prefix = File(ctx.filesDir, "prefix").apply { mkdirs() }
        val cmd = listOf(
            "${root}/bin/box64", "${root}/wine/bin/wine64", entry.exePath
        ) + entry.wineArgs.split(" ").filter { it.isNotBlank() }
        return ProcessBuilder(cmd)
            .directory(prefix)
            .apply { environment()["WINEPREFIX"] = prefix.absolutePath }
            .redirectErrorStream(true)
            .start()
    }
}
