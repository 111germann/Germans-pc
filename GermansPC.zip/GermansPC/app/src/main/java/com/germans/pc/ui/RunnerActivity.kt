package com.germans.pc.ui

import android.app.Activity
import android.os.Bundle
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import com.germans.pc.engine.AppEntry
import com.germans.pc.engine.Engine
import com.germans.pc.input.InputMapper
import com.germans.pc.input.InputSink

/** Экран, где идёт сама программа/игра. Ловит ввод и отдаёт в InputMapper. */
class RunnerActivity : Activity(), InputSink {
    private val mapper = InputMapper(this)
    private lateinit var surface: View

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        surface = View(this).apply { isFocusable = true; isFocusableInTouchMode = true }
        setContentView(surface)
        surface.requestFocus()
        surface.requestPointerCapture() // мышь как на ПК
        val entry = AppEntry(intent.getStringExtra("name") ?: "", intent.getStringExtra("exe") ?: "")
        Thread { Engine(this).launch(entry) }.start()
    }

    override fun dispatchKeyEvent(e: KeyEvent) = mapper.onKey(e) || super.dispatchKeyEvent(e)
    override fun dispatchGenericMotionEvent(e: MotionEvent) = mapper.onGeneric(e) || super.dispatchGenericMotionEvent(e)

    // TODO: передавать в XServer / Wine
    override fun key(code: Int, down: Boolean) {}
    override fun mouseMove(dx: Float, dy: Float) {}
    override fun mouseButton(button: Int, down: Boolean) {}
    override fun scroll(v: Float) {}
    override fun axis(axis: Int, value: Float) {}
}
