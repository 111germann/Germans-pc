package com.germans.pc

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.germans.pc.engine.AppEntry
import com.germans.pc.ui.RunnerActivity

class MainActivity : ComponentActivity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { Home() } }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Home() {
    val ctx = LocalContext.current
    val apps = remember { mutableStateListOf<AppEntry>() }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri?.let {
            ctx.contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            apps += AppEntry(it.lastPathSegment?.substringAfterLast('/')?.removeSuffix(".exe") ?: "Программа", it.toString())
        }
    }
    Scaffold(
        topBar = { TopAppBar(title = { Text("Germans PC") }) },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { picker.launch(arrayOf("application/*", "*/*")) },
                icon = { Icon(Icons.Default.Add, null) },
                text = { Text("Добавить .exe") }
            )
        }
    ) { pad ->
        if (apps.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(pad), Alignment.Center) {
                Text("Нажмите «Добавить .exe», чтобы начать")
            }
        } else {
            LazyVerticalGrid(
                GridCells.Adaptive(150.dp), Modifier.padding(pad),
                contentPadding = PaddingValues(16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(apps) { app -> AppCard(app) {
                    ctx.startActivity(Intent(ctx, RunnerActivity::class.java)
                        .putExtra("name", app.name).putExtra("exe", app.exePath))
                } }
            }
        }
    }
}

/** Карточка с подсветкой фокуса: удобно с геймпада (D-pad) и клавиатуры (Tab/стрелки). */
@Composable
fun AppCard(app: AppEntry, onRun: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    Card(
        Modifier.fillMaxWidth().height(110.dp)
            .onFocusChanged { focused = it.isFocused }
            .border(if (focused) 3.dp else 0.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(12.dp))
            .clickable(onClick = onRun)
    ) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.SpaceBetween) {
            Text(app.name, style = MaterialTheme.typography.titleMedium, maxLines = 2)
            Icon(Icons.Default.PlayArrow, "Запустить")
        }
    }
}
