package com.germans.pc.input

import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent

/** Единая точка для клавиатуры, мыши и геймпада. Отправка в Wine: TODO (XServer/uinput). */
interface InputSink {
    fun key(code: Int, down: Boolean)
    fun mouseMove(dx: Float, dy: Float)
    fun mouseButton(button: Int, down: Boolean)
    fun scroll(v: Float)
    fun axis(axis: Int, value: Float)
}

class InputMapper(private val sink: InputSink) {

    fun onKey(e: KeyEvent): Boolean {
        val down = e.action == KeyEvent.ACTION_DOWN
        sink.key(e.keyCode, down) // клавиатура и кнопки геймпада (BUTTON_A и т.д.)
        return true
    }

    fun onGeneric(e: MotionEvent): Boolean {
        val src = e.source
        return when {
            src and InputDevice.SOURCE_JOYSTICK == InputDevice.SOURCE_JOYSTICK -> {
                for (a in intArrayOf(
                    MotionEvent.AXIS_X, MotionEvent.AXIS_Y, MotionEvent.AXIS_Z, MotionEvent.AXIS_RZ,
                    MotionEvent.AXIS_LTRIGGER, MotionEvent.AXIS_RTRIGGER,
                    MotionEvent.AXIS_HAT_X, MotionEvent.AXIS_HAT_Y
                )) {
                    val v = e.getAxisValue(a)
                    sink.axis(a, if (kotlin.math.abs(v) < 0.1f) 0f else v) // мёртвая зона
                }
                true
            }
            src and InputDevice.SOURCE_MOUSE != 0 -> {
                if (e.actionMasked == MotionEvent.ACTION_SCROLL)
                    sink.scroll(e.getAxisValue(MotionEvent.AXIS_VSCROLL))
                true
            }
            else -> false
        }
    }

    /** Мышь с захваченным указателем (relative) и тачпад-режим. */
    fun onCaptured(e: MotionEvent): Boolean {
        sink.mouseMove(e.x, e.y)
        val b = e.buttonState
        sink.mouseButton(0, b and MotionEvent.BUTTON_PRIMARY != 0)
        sink.mouseButton(1, b and MotionEvent.BUTTON_SECONDARY != 0)
        return true
    }
}
